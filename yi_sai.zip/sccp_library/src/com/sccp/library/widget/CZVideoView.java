package com.sccp.library.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.VideoView;

public class CZVideoView extends VideoView {

    public CZVideoView(Context context) { 
        super(context); 
    }
    
    public CZVideoView(Context context, AttributeSet attrs) { 
        super(context, attrs); 
    }
	 
	public CZVideoView(Context context, AttributeSet attrs, int defStyle) { 
        super(context, attrs, defStyle); 
    }
}
